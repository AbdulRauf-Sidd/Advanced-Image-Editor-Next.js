
declare namespace NodeJS {
    interface ProcessEnv {
      readonly OPENAI_API_KEY: string;
      readonly OPENAI_ASSISTANT_ID: string;
      readonly MONGODB_URI: string;
      readonly CLOUDFLARE_ACCOUNT_ID;
      readonly CLOUDFLARE_R2_BUCKET;
      readonly CLOUDFLARE_R2_ACCESS_KEY_ID;
      readonly CLOUDFLARE_R2_SECRET_ACCESS_KEY;
      readonly CLOUDFLARE_R2_ENDPOINT;
      readonly CLOUDFLARE_PUBLIC_URL;
      // Add other environment variables here
    }
  }